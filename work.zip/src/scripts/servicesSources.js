import badal1 from "../assests/red1.svg";

const servicesSources =  [
    {
      title: "Extensive network of volunteers, hospitals, and doctors",
      image: badal1,
      cardText:"Our extensive network of volunteers, hospitals and doctors, ensure that you get the best care possible in the nick of time",
    },
  
    
  ];
  
  export default servicesSources;