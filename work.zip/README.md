# React Starter
With SCSS and JSX compatibility